# CS3035 – Sketches

## I do not know where the original file went i apologize for any inconvenience


![](src/sketches/thumbnail_20211205_2228493.jpg)


![](src/sketches/thumbnail_20211205_2229242.jpg)


![](src/sketches/thumbnail_20211205_2229591.jpg)


![](src/sketches/GetAttachmentThumbnail.jpg)