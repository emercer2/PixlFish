# Sketches Description

Provide a short description that can help someone understand the images you have provided.

Following the README.md file you should provide:
- images/photos of all sketches that were used to plan the applications design, use sticky notes to describe how you used these to guide your final design, copy these into the sketches folder in your submission... edit the SKETCHES.md file to describe the images.
- You can add these below by putting images in the images folder and using the following markdown ```![Rick](images/roll.gif)```
- Delete these description lines (and Rick)

![Rick](images/roll.gif)

